function archerForm() {
    const archerInfo = $("form .page-1");
    const distantInfo = $("form .page-2");
    const arrowInfo = $("form .page-3");

    const rightBtn = $("form .right-btn");
    const scoreBtn = $("form #edit-score");
    const closeBtn = $("form #close");
    const submitBtn = $("form .submit-btn");
    const saveBtn = $("form .save-btn");

    let digitInput = $(".digit")

    let submitInput = {};
    let saveInput = {};


    rightBtn.on("click", function() {
        nextPage();
    });

    // Distant Form - Start - //
    scoreBtn.on("click", function() {
        openPopUpPage();
    });

    $("#ends-min, #ends-max").on("input", function() {
        let endsMinValue = $("#ends-min").val();
        let endsMaxValue = $("#ends-max").val();

        validateEndNum(saveInput, endsMinValue, endsMaxValue);
    })

    submitBtn.on("click", function(event) {
        event.preventDefault();
        getSearchInput();

        let endsMaxValue = $("#ends-max").val();
        // - Validate Success - //
        if (validateEndScore(saveInput, endsMaxValue)) {
            submitInput["scoreList"] = saveInput;
            console.log("done", submitInput);
        }
    });
    // Distant Form - End - //

    // Scoring Form - Start - //
    closeBtn.on("click", function() {
        closePopUpPage();
    });

    digitInput.on("keydown", function(event) {
        validateScoring(event);
    });

    saveBtn.on("click", function(event) {
        event.preventDefault();
        getSaveInput();
        // console.log("save", saveInput);
    });
    // Scoring Form - End - //

    function getSaveInput() {
        let endMin = $("#ends-min").val();
        validateSaveInput(endMin, digitInput, saveInput);
    }

    function getSearchInput() {
        // Page 1
        let round = $("#round").val();
        let archer = $("#archer").val();
        let equipment = $("#equipment").val();
        // console.log(round, archer, equipment);

        // Page 2
        let endMin = $("#ends-min").val();
        let endMax = $("#ends-max").val();
        let range = $("#range").val();
        let target = $("#target").val();
        // console.log(endMin, endMax, range, target);

        return submitInput = {
            roundName: round, 
            archerId: archer, 
            equipment: equipment,
            endMin: endMin,
            endMax: endMax,
            range: range,
            targetSize: target
        }
    }

    function nextPage() {
        archerInfo.removeClass("active");
        distantInfo.addClass("active");
    }

    function openPopUpPage() {
        distantInfo.removeClass("active");
        arrowInfo.addClass("active");
    }

    function closePopUpPage() {
        arrowInfo.removeClass("active");
        distantInfo.addClass("active");
    }
}