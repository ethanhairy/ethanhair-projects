$(document).ready(function() {
    $("#error").hide();
    $("#success").hide();
    $("#edit-score").prop("disabled", true);
    archerForm();
});