function validateEndNum(saveInput, endsMinValue, endsMaxValue) {
    if (endsMinValue !== "" && endsMaxValue !== "") {
        console.log("End Number: " + endsMinValue + " / " + endsMaxValue + " - Not Empty");
        $("#notdone").hide();

        if ((parseInt(endsMaxValue) < parseInt(endsMinValue)) || (parseInt(endsMaxValue) < 1 || parseInt(endsMinValue) < 1)) {
            $("#success").hide();
            $("#error").show();
            $("#edit-score").prop("disabled", true).addClass("disabled");
        } else {
            $("#error").hide();
            $("#edit-score").prop("disabled", false).removeClass("disabled");

            $(".save-btn").click(function() {
                if (validateEndScore(saveInput, endsMaxValue)) {
                    $("#error").hide();
                    $("#success").show();
                } else {
                    $("#success").hide();
                }
            })
            
        }

    } else {
        $("#error").hide();
        $("#success").hide();
        $("#notdone").show();
        $("#edit-score").prop("disabled", true).addClass("disabled");
    }
}

function validateSaveInput(endMin, digitInput, saveInput) {
    if (endMin !== "") {
        let totalScore = 0;
        let arrowScores = [];
        const validValues = ["X", 9, 8, 7, 6, 5, 4, 3, 2, 1, "M"];

        digitInput.each(function() {
            let value = $(this).val();

            if (value !== "") {
                let parsedNumber = parseInt(value);

                if (!isNaN(parsedNumber)) {

                    value = parsedNumber;
                }

                arrowScores.push(value);

                if (validValues.includes(value)) {

                    totalScore += (value === "X" ? 10 : value === "M" ? 0 : parseInt(value));
                }
            }
        });

        saveInput[endMin] = arrowScores;
        $("#total").text("Total: " + totalScore);
    }
}

function validateScoring(event) {
    const key = event.key.toUpperCase();
    const allowedChars = "X123456789M";

    if (event.keyCode === 8 || event.keyCode === 9) {
        return true; // Allow backspace and tab
    }

    if (!allowedChars.includes(key)) {
        event.preventDefault(); 
    }
}


function validateEndScore(saveInput, endsMaxValue) {
    const arrlimit = 6;

    
    // Check if max score array is missing
    if (saveInput[endsMaxValue] === undefined) {
        console.log("Error: You did not fill all the scores");
    } else {
    // Loop through all scores up to max (inclusive)
        for (let i = 1; i <= endsMaxValue; i++) {
            const currentScore = saveInput[i];

            // Check if current score array is missing or has missing values
            if (currentScore === undefined || currentScore.length < arrlimit) {
                // Return
                console.log(`Error: Scores for end ${i} is missing or incomplete. Must have length is ${arrlimit}.`);
                return false;
            }
        }
        // return 
        console.log("Submit is Successful");
        return true;
    }
}